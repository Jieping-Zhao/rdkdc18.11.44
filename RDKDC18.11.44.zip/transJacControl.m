function finalerr=transJacControl(gdesired,K,ur5)

    T = 0.1;

    xi = [1;1;1;1;1;1];
    
    while (norm(xi(1:3))> 0.01 || norm(xi(4:6)) > 0.03)

        q = ur5.get_current_joints();
        gst = ur5FwdKin(q);
        Jb = ur5BodyJacobian(q);
        xi = getXi(gdesired\gst);


       dq = -transpose(Jb) * K * xi;
        
       for i = 1:6
            if 0.8*abs(dq(i))/T > pi * ur5.speed_limit
                dq(i) = 0.99 * sign(dq(i))*pi * ur5.speed_limit * T;
            end
        end

        q = q + dq;

        ur5.move_joints(q, T);
        pause(1.2*T);


    end
    err = gdesired\gst;
    finalerr = norm(err(1:3,4));
    
end