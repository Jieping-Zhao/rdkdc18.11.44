clear; clc;

q = [0;0;0;0;0;0];
size(q,2)


